<section class="section partners">
    <div class="container">
        <h2 class="section__title" data-aos="fade-right">Нам доверяют</h2>
        <div class="partners__wrapper swiper">
            <div class="swiper-wrapper">
                <div class="swiper-slide scale">
                    <a target="_blank" class="partner not-effect" href="https://neiros.ru" data-aos="zoom-in" data-aos-duration="2000">
                        <img data-img-svg class="partner__img" data-src="<?= ASSETS_PATH ?>images/icons/neiros.svg" alt="Neiros">
                    </a>
                </div>
                <div class="swiper-slide scale">
                    <a target="_blank" class="partner partner_goreally not-effect" href="https://goreally.group" data-aos="zoom-in" data-aos-duration="2000">
                        <img data-img-svg class="partner__img" data-src="<?= ASSETS_PATH ?>images/icons/goreally.svg" alt="GOREALLY GROUP">
                    </a>
                </div>
            </div>
            <div class="swiper-scrollbar"></div>
        </div>
    </div>
</section>