<section class="section hero hero_start">
    <div class="container">
        <h1 class="hero__title" data-aos="fade-down" data-aos-duration="1000" data-aos-delay="0">Давайте начнем проект вместе</h1>
        <p class="hero__subtitle" data-aos="fade-down" data-aos-duration="1000" data-aos-delay="150">
            Возможно, ваш бизнес получит выгоду от сотрудничества с
            агентством ITRinity? Поделитесь своими контактами в форме ниже, и мы ответим в течение 48 часов с момента получения запроса.
        </p>
    </div>
</section>