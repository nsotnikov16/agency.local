
<section class="section">
    <div class="container">
        <hr>
        <h2 class="lead__title">Есть проект на примете?<br> Давайте приступим к работе.</h2>
        <div style="display: flex; justify-content: center; margin-top: 3%">
            <a href="/start/" class="btn not-effect">Начать проект</a>
        </div>
    </div>
</section>