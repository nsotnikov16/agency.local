<?
define('TEMPLATE_PATH', '/dev/template/');
define('ASSETS_PATH', '/dev/assets/');
define('VIEWS_PATH', TEMPLATE_PATH . 'views/');
define('TELEGRAM_TOKEN', '6460105098:AAE5oaPLQCet4RAxp21ihAWdABItBxBeyuQ');
define('TELEGRAM_CHATID', '997646148');
define('CURRENT_URL', (isset($_SERVER['HTTPS']) && !empty($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST']);